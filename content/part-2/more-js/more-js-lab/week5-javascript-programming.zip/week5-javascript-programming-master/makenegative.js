function make_negative(num) {
  // returns the negative value of the number
}

module.exports = make_negative;
