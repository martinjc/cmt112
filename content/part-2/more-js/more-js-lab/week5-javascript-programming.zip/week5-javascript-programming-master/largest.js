function largest_in_list(arr) {
  // returns the largest value in the supplied list
  return -1;
}

module.exports = largest_in_list;
