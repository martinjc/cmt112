function hello(name) {
  // should return "hello name"
  return -1;
}

module.exports = hello;
