function is_palindrome(word) {
  // returns true if word is a palindrome, false otherwise
  return -1;
}

module.exports = is_palindrome;
