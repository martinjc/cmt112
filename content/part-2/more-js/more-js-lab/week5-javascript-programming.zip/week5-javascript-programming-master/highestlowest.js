function highestlowest(input) {
    // accepts a string as input, which will be space separated numbers, and you must return the highest and lowest number in the string as a space separated string, highest number first
}

module.exports = highestlowest;