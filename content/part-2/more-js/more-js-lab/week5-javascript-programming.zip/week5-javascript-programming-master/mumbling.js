function mumble(input) {
    // accepts a string as input, and returns a new string with the first character repeated once, the second twice, and so on. The first character of each string of repeats should be upper case
}

module.exports = mumble;