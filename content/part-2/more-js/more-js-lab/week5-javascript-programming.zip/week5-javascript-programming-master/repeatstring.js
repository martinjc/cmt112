function repeat_string(s, n) {
  // returns a string with the string s repeated n times
}

module.exports = repeat_string;
